from flask import Flask,render_template,request
import requests

app=Flask(__name__)
API_KEY="#################"


@app.route("/",methods=["GET","POST"])
def index():
    data=None
    error=None
    symbol=""

    if request.method == "POST":
        symbol=request.form.get("symbol","").upper().strip()

        url=f"http://api.marketstack.com/v1/eod?access_key={API_KEY}&symbols={symbol}&limit=1&sort=DESC"
        response=requests.get(url)
        result=response.json()
        print(result)

        if "error" in result:
            error=result["error"]["message"]
        elif not result["data"]:
            error=f"No data found for {symbol}"
        else:
            quote=result["data"][0]
            data={
                "symbol": quote["symbol"],
                "data":quote["date"][:10],
                "open":round(quote["open"],2),
                "high":round(quote["high"],2),
                "low": round(quote["low"], 2),
                "close": round(quote["close"],2),
                "volume": int(quote["volume"]),
            }
    return render_template("index.html",data=data,symbol=symbol,error=error)

if __name__=="__main__":
    app.run(debug=True)